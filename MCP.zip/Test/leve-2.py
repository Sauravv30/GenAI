import asyncio
import hashlib
import json

import litellm
from dotenv import load_dotenv
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

load_dotenv()

MODEL = "groq/llama-3.3-70b-versatile"

server_params = StdioServerParameters(
    command="python",
    args=["hotel_server.py"]
)

# ---------------------------
# Utility: Tool Result Cache
# ---------------------------

class ToolCache:
    def __init__(self):
        self.cache = {}

    def key(self, name, args):
        raw = name + json.dumps(args, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, name, args):
        return self.cache.get(self.key(name, args))

    def set(self, name, args, value):
        self.cache[self.key(name, args)] = value


# ---------------------------
# Retry Utility
# ---------------------------

async def retry(func, retries=3, delay=1):
    for attempt in range(retries):
        try:
            return await func()
        except Exception as e:
            if attempt == retries - 1:
                raise
            await asyncio.sleep(delay)


# ---------------------------
# MCP Agent
# ---------------------------

class MCPAgent:

    def __init__(self, model, tools):
        self.model = model
        self.tools = tools
        self.messages = [
            {
                "role": "system",
                "content": "You are a helpful assistant. Use tools when required."
            }
        ]
        self.cache = ToolCache()

    def add_user_message(self, text):
        self.messages.append({"role": "user", "content": text})

    def add_tool_result(self, call_id, result):
        self.messages.append({
            "role": "tool",
            "tool_call_id": call_id,
            "content": result
        })

    # ---------------------------
    # Streaming LLM call
    # ---------------------------

    async def stream_llm(self):

        response = litellm.completion(
            model=self.model,
            messages=self.messages,
            tools=self.tools,
            tool_choice="auto",
            stream=True
        )

        final_message = None

        for chunk in response:

            if "choices" not in chunk:
                continue

            delta = chunk["choices"][0]["delta"]

            if "content" in delta:
                print(delta["content"], end="", flush=True)

            if "tool_calls" in delta:
                final_message = chunk["choices"][0]["message"]

        print()

        if final_message:
            return final_message

        # fallback (non-tool response)
        response = litellm.completion(
            model=self.model,
            messages=self.messages,
            tools=self.tools
        )

        return response["choices"][0]["message"]


# ---------------------------
# Parallel Tool Executor
# ---------------------------

async def execute_tool(session, cache, tool_call):

    tool_name = tool_call["function"]["name"]
    args = json.loads(tool_call["function"]["arguments"])

    cached = cache.get(tool_name, args)
    if cached:
        return tool_call["id"], cached

    async def run():
        result = await session.call_tool(
            tool_name,
            arguments=args
        )

        text = ""
        for c in result.content:
            if hasattr(c, "text"):
                text += c.text

        return text

    text = await retry(run)

    cache.set(tool_name, args, text)

    return tool_call["id"], text


# ---------------------------
# Main Agent Runner
# ---------------------------

async def main():

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:

            await session.initialize()

            tools = await session.list_tools()

            tool_schemas = []

            for tool in tools.tools:
                tool_schemas.append({
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.inputSchema,
                    }
                })

            agent = MCPAgent(MODEL, tool_schemas)

            agent.add_user_message("Get hotel with id 1")

            while True:

                msg = await agent.stream_llm()

                if msg.get("tool_calls"):

                    tasks = []

                    for call in msg["tool_calls"]:
                        tasks.append(
                            execute_tool(
                                session,
                                agent.cache,
                                call
                            )
                        )

                    results = await asyncio.gather(*tasks)

                    for call_id, text in results:
                        agent.add_tool_result(call_id, text)

                    continue

                print("\nFinal Answer:\n")
                print(msg["content"])
                break


if __name__ == "__main__":
    asyncio.run(main())