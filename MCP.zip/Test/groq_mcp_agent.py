import asyncio
import json
import os
from dotenv import load_dotenv
from openai import AsyncOpenAI

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

load_dotenv()

# Groq OpenAI-compatible client
groq = AsyncOpenAI(
    api_key=os.getenv("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1",
)

MODEL = "llama-3.3-70b-versatile"

server_params = StdioServerParameters(
    command="python",
    args=["hotel_server.py"]
)


async def main():
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:

            await session.initialize()

            tools = await session.list_tools()

            tool_schemas = []

            for tool in tools.tools:
                tool_schemas.append(
                    {
                        "type": "function",
                        "function": {
                            "name": tool.name,
                            "description": tool.description,
                            "parameters": tool.inputSchema,
                        },
                    }
                )

            messages = [
                {
                    "role": "system",
                    "content": "You are a hotel assistant. Use tools when required.",
                }
            ]

            messages.append(
                {"role": "user", "content": "Get hotel with id 1"}
            )

            while True:

                response = await groq.chat.completions.create(
                    model=MODEL,
                    messages=messages,
                    tools=tool_schemas,
                    tool_choice="auto",
                )

                msg = response.choices[0].message

                if msg.tool_calls:

                    for call in msg.tool_calls:

                        tool_name = call.function.name
                        args = json.loads(call.function.arguments)

                        print(f"\nCalling tool: {tool_name} {args}")

                        result = await session.call_tool(
                            tool_name,
                            arguments=args
                        )

                        messages.append(
                            {
                                "role": "assistant",
                                "content": None,
                                "tool_calls": [
                                    {
                                        "id": call.id,
                                        "type": "function",
                                        "function": {
                                            "name": tool_name,
                                            "arguments": json.dumps(args)
                                        }
                                    }
                                ],
                            }
                        )

                        tool_text = ""

                        for c in result.content:
                            if hasattr(c, "text"):
                                tool_text += c.text

                        messages.append(
                            {
                                "role": "tool",
                                "tool_call_id": call.id,
                                "content": tool_text,
                            }
                        )

                    continue

                print("\nAgent response:\n")
                print(msg.content)

                break


if __name__ == "__main__":
    asyncio.run(main())
