import requests
import json
import httpx
BASE_URL = "http://localhost:9082"


class APIClient:

    def __init__(self):
        self.headers = {"Content-Type": "application/json"}

    def create_hotel(self, data):
        r = requests.post(
            f"{BASE_URL}/hotel/create",
            json=data,
            headers=self.headers
        )
        return r.json()

    async def get_hotel(self, hotel_id):
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{BASE_URL}/hotel/{hotel_id}")

            if r.status_code != 200:
                return {"error": f"API returned {r.status_code}"}

            return r.json()

    def add_room(self, data):
        r = requests.post(
            f"{BASE_URL}/room/add",
            json=data,
            headers=self.headers
        )
        return r.json()

    def update_room(self, room_id, data):
        r = requests.put(
            f"{BASE_URL}/room/update/{room_id}",
            json=data,
            headers=self.headers
        )
        return r.json()

    def get_room(self, room_id):
        r = requests.get(f"{BASE_URL}/room/{room_id}")
        return r.json()

    def book_room(self, room_id, status):
        r = requests.put(f"{BASE_URL}/room/book/{room_id}/{status}")
        return r.json()