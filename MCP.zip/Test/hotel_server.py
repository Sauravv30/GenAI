from fastmcp import FastMCP

from hotel_api_client import APIClient

mcp = FastMCP("Hotel Management MCP")

client = APIClient()


@mcp.tool()
async def get_hotel(hotel_id: int):
    """
    Retrieve hotel details by hotel ID.
    """
    return await client.get_hotel(hotel_id)


if __name__ == "__main__":
    print("MCP Starting")
    mcp.run(transport="stdio")
