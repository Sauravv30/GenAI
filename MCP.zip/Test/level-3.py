# “agent loop” → “agent runtime”

import asyncio
import json
import hashlib
from dataclasses import dataclass

import litellm

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

MODEL = "groq/llama-3.3-70b-versatile"


# ===============================
# Memory System
# ===============================

class AgentMemory:

    def __init__(self):
        self.messages = []
        self.tool_cache = {}

    def add(self, role, content):
        self.messages.append({"role": role, "content": content})

    def get_messages(self):
        return self.messages

    def cache_key(self, name, args):
        raw = name + json.dumps(args, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()

    def get_tool_cache(self, name, args):
        return self.tool_cache.get(self.cache_key(name, args))

    def set_tool_cache(self, name, args, result):
        self.tool_cache[self.cache_key(name, args)] = result


# ===============================
# MCP Server Manager
# ===============================

@dataclass
class MCPServer:
    name: str
    command: str
    args: list


class MCPToolRegistry:

    def __init__(self):
        self.tools = []
        self.sessions = {}

    async def connect_server(self, server: MCPServer):

        params = StdioServerParameters(
            command=server.command,
            args=server.args
        )

        ctx = stdio_client(params)
        read, write = await ctx.__aenter__()

        session = ClientSession(read, write)
        print("Session starting")
        await session.initialize()
        print("Session Completed")
        self.sessions[server.name] = session
        self.contexts[server.name] = ctx

        tools = await session.list_tools()

        for tool in tools.tools:
            self.tools.append({
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.inputSchema
                },
                "server": server.name
            })

    def get_tools(self):
        return self.tools

    def get_session(self, server_name):
        return self.sessions[server_name]

async def shutdown(self):

    for name, ctx in self.registry.contexts.items():
        await ctx.__aexit__(None, None, None)
# ===============================
# Planner Agent (ReAct)
# ===============================

class PlannerAgent:

    def __init__(self, memory, tools):
        self.memory = memory
        self.tools = tools

    async def plan(self):

        messages = self.memory.get_messages()

        system_prompt = {
            "role": "system",
            "content": """
You are an AI planner.

Use ReAct reasoning:

Thought: reasoning
Action: tool_name
Action Input: json
Observation: tool result

Repeat until final answer.
"""
        }

        response = litellm.completion(
            model=MODEL,
            messages=[system_prompt] + messages,
            tools=self.tools,
            tool_choice="auto"
        )

        return response["choices"][0]["message"]


# ===============================
# Tool Executor
# ===============================

class ToolExecutor:

    def __init__(self, registry, memory):
        self.registry = registry
        self.memory = memory

    async def execute(self, tool_call):

        name = tool_call["function"]["name"]
        args = json.loads(tool_call["function"]["arguments"])

        cached = self.memory.get_tool_cache(name, args)
        if cached:
            return cached

        for tool in self.registry.tools:

            if tool["function"]["name"] == name:

                session = self.registry.get_session(tool["server"])

                result = await session.call_tool(name, arguments=args)

                text = ""

                for c in result.content:
                    if hasattr(c, "text"):
                        text += c.text

                self.memory.set_tool_cache(name, args, text)

                return text


# ===============================
# Critic Agent (Optional)
# ===============================

class CriticAgent:

    async def review(self, answer):

        prompt = [
            {
                "role": "system",
                "content": "Review the answer and improve if needed."
            },
            {"role": "user", "content": answer}
        ]

        response = litellm.completion(
            model=MODEL,
            messages=prompt
        )

        return response["choices"][0]["message"]["content"]


# ===============================
# Runtime
# ===============================

class AgentRuntime:

    def __init__(self):

        self.memory = AgentMemory()
        self.registry = MCPToolRegistry()

    async def start(self):

        servers = [
            MCPServer("hotel", "python", ["hotel_server.py"]),
        ]
        print("Started mcp")
        for s in servers:
            await self.registry.connect_server(s)
        print("Registered mcp servers")
        self.planner = PlannerAgent(
            self.memory,
            self.registry.get_tools()
        )

        self.executor = ToolExecutor(
            self.registry,
            self.memory
        )

        self.critic = CriticAgent()

    async def run(self, query):

        self.memory.add("user", query)

        while True:

            msg = await self.planner.plan()

            if msg.get("tool_calls"):

                for call in msg["tool_calls"]:

                    result = await self.executor.execute(call)

                    self.memory.messages.append({
                        "role": "tool",
                        "content": result
                    })

                continue

            answer = msg["content"]

            answer = await self.critic.review(answer)

            print("\nFINAL ANSWER:\n")
            print(answer)

            break


# ===============================
# MAIN
# ===============================

async def main():

    runtime = AgentRuntime()

    await runtime.start()

    print("Init complete")

    await runtime.run("Find hotel with id 1")

    await runtime.shutdown()

if __name__ == "__main__":
    asyncio.run(main())