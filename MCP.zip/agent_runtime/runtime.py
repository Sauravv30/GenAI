class AgentRuntime:

    def __init__(self):

        self.memory = VectorMemory()
        self.planner = TaskPlanner()
        self.tools = ToolEmbeddingIndex()

    async def run(self, query):

        # retrieve memory
        past = self.memory.search(query)

        steps = await self.planner.decompose(query)

        results = []

        for step in steps:

            tools = self.tools.find_best_tools(step)

            result = f"Executed {step} using {tools}"

            results.append(result)

            self.memory.store(result)

        return "\n".join(results)