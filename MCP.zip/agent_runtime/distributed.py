import redis
import json

r = redis.Redis()

class DistributedQueue:

    def push_task(self, task):

        r.lpush("agent_tasks", json.dumps(task))

    def pop_task(self):

        data = r.brpop("agent_tasks")

        if data:
            return json.loads(data[1])