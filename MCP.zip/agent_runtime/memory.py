import faiss
import numpy as np
import litellm

class VectorMemory:

    def __init__(self):

        self.index = faiss.IndexFlatL2(1536)
        self.texts = []

    def embed(self, text):

        emb = litellm.embedding(
            model="text-embedding-3-small",
            input=text
        )

        return np.array(emb["data"][0]["embedding"]).astype("float32")

    def store(self, text):

        vector = self.embed(text)
        self.index.add(np.array([vector]))
        self.texts.append(text)

    def search(self, query, k=3):

        vector = self.embed(query)
        D, I = self.index.search(np.array([vector]), k)

        return [self.texts[i] for i in I[0] if i < len(self.texts)]