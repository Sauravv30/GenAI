import litellm

class TaskPlanner:

    async def decompose(self, query):

        prompt = f"""
Break this task into steps:

Task: {query}

Return JSON list of steps.
"""

        response = litellm.completion(
            model="groq/llama-3.3-70b-versatile",
            messages=[{"role":"user","content":prompt}]
        )

        import json
        return json.loads(response["choices"][0]["message"]["content"])