class ToolExecutor:

    async def execute(self, session, tool_name, args):

        try:

            return await session.call_tool(
                tool_name,
                arguments=args
            )

        except Exception as e:

            fix_prompt = f"""
Tool failed.

Tool: {tool_name}
Args: {args}
Error: {e}

Suggest corrected arguments.
"""

            response = litellm.completion(
                model="groq/llama-3.3-70b-versatile",
                messages=[{"role":"user","content":fix_prompt}]
            )

            new_args = json.loads(
                response["choices"][0]["message"]["content"]
            )

            return await session.call_tool(
                tool_name,
                arguments=new_args
            )