class ToolEmbeddingIndex:

    def __init__(self):
        self.tools = []
        self.index = faiss.IndexFlatL2(1536)

    def add_tool(self, name, description):

        emb = litellm.embedding(
            model="text-embedding-3-small",
            input=description
        )

        vec = np.array(emb["data"][0]["embedding"]).astype("float32")

        self.index.add(np.array([vec]))
        self.tools.append(name)

    def find_best_tools(self, query, k=3):

        emb = litellm.embedding(
            model="text-embedding-3-small",
            input=query
        )

        vec = np.array(emb["data"][0]["embedding"]).astype("float32")

        D, I = self.index.search(np.array([vec]), k)

        return [self.tools[i] for i in I[0]]